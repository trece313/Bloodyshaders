# Minecraft Shader

## Description
Basically, a Minecraft shader to create a darker, bloodier atmosphere this October 31st for Halloween. Enjoy it, and have a Happy Halloween 2024!

## License
This shader is free to use and distribute for any purpose under an open-source license. You can modify and share it as you wish.

## Features
- Darker, bloodier atmosphere
- Perfect for Halloween

## Installation
1. Download the shader files.
2. Place them in the `shaders` folder of your Minecraft directory.
3. Select the shader in Minecraft settings.

## Usage
Feel free to use and share this shader in your own Minecraft adventures!

